import AdminSection from "./AdminSections/AdminSection"

const Admin = () => {
  return (
    <div>
      <AdminSection/>
    </div>
  )
}

export default Admin