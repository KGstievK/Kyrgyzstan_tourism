import scss from './AddCategory.module.scss'

const AddCategory = () => {
  return (
    <section className={scss.AddCategory}>
      <div className="container">
        <div className={scss.content}>
          <h1>AddCategory</h1>
        </div>
      </div>
    </section>
  )
}

export default AddCategory