import React from 'react';
import Culture from '../culture/Culture'; 
const Home: React.FC = () => {
  return (
    <div>
      
      <Culture />
    </div>
  );
};

export default Home;
