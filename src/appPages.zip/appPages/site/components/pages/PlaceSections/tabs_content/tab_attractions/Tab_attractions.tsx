import useTranslate from '@/appPages/site/hooks/translate/translate';
import scss from './Tab_attractions.module.scss';
// import imgAtt from '@/images/cultural-evening.png'
const Tab_attractions = () => {

    const {t} = useTranslate()

    return (
        <div className={scss.attractions}>

        </div>
    );
};

export default Tab_attractions;