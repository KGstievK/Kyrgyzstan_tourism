import HomeSection from "./HomeSections/HomeComponents"


const Home = () => {
  return (
    <div>
      <HomeSection/>
    </div>
  )
}

export default Home